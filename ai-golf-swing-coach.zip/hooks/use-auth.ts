import * as Api from "@/lib/_core/api";
import * as Auth from "@/lib/_core/auth";
import { useCallback, useEffect, useMemo, useState } from "react";
import { Platform } from "react-native";
import { describeError } from "@/lib/safe-diagnostics";

type UseAuthOptions = {
  autoFetch?: boolean;
};

export function useAuth(options?: UseAuthOptions) {
  const { autoFetch = true } = options ?? {};
  const [user, setUser] = useState<Auth.User | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);

  const fetchUser = useCallback(async () => {
        try {
      setLoading(true);
      setError(null);

      // Web platform: use cookie-based auth, fetch user from API
      if (Platform.OS === "web") {
                const apiUser = await Api.getMe();
        
        if (apiUser) {
          const userInfo: Auth.User = {
            id: apiUser.id,
            openId: apiUser.openId,
            name: apiUser.name,
            email: apiUser.email,
            loginMethod: apiUser.loginMethod,
            lastSignedIn: new Date(apiUser.lastSignedIn),
          };
          setUser(userInfo);
          // Cache user info in localStorage for faster subsequent loads
          await Auth.setUserInfo(userInfo);
                  } else {
                    setUser(null);
          await Auth.clearUserInfo();
        }
        return;
      }

      // Native platform: use token-based auth
            const sessionToken = await Auth.getSessionToken();
            if (!sessionToken) {
                setUser(null);
        return;
      }

      // Use cached user info for native (token validates the session)
      const cachedUser = await Auth.getUserInfo();
            if (cachedUser) {
                setUser(cachedUser);
      } else {
                setUser(null);
      }
    } catch (err) {
      const error = err instanceof Error ? err : new Error("Failed to fetch user");
      console.error(`[useAuth] fetchUser failed (${describeError(error)})`);
      setError(error);
      setUser(null);
    } finally {
      setLoading(false);
          }
  }, []);

  const logout = useCallback(async () => {
    try {
      await Api.logout();
    } catch (err) {
      console.error(`[Auth] logout failed (${describeError(err)})`);
      // Continue with logout even if API call fails.
    }

    let cleanupError: Error | null = null;
    try {
      await Auth.removeSessionToken();
    } catch (err) {
      cleanupError = err instanceof Error ? err : new Error("Could not clear the local session token");
      console.error(`[Auth] local session cleanup failed (${describeError(err)})`);
    }
    try {
      await Auth.clearUserInfo();
    } catch (err) {
      cleanupError ??= err instanceof Error ? err : new Error("Could not clear cached user info");
      console.error(`[Auth] cached user cleanup failed (${describeError(err)})`);
    }
    setUser(null);
    setError(cleanupError);
  }, []);

  const isAuthenticated = useMemo(() => Boolean(user), [user]);

  useEffect(() => {
        if (autoFetch) {
      if (Platform.OS === "web") {
        // Web: fetch user from API directly (user will login manually if needed)
                fetchUser();
      } else {
        // Native: check for cached user info first for faster initial load
        void Auth.getUserInfo().then((cachedUser) => {
                    if (cachedUser) {
                        setUser(cachedUser);
            setError(null);
            setLoading(false);
          } else {
            // No cached user, check session token
            void fetchUser();
          }
        }).catch((err) => {
          console.error(`[useAuth] cached user check failed (${describeError(err)})`);
          setError(err instanceof Error ? err : new Error("Could not read cached user"));
          void fetchUser();
        });
      }
    } else {
            setLoading(false);
    }
  }, [autoFetch, fetchUser]);

  useEffect(() => {
      }, [user, loading, isAuthenticated, error]);

  return {
    user,
    loading,
    error,
    isAuthenticated,
    refresh: fetchUser,
    logout,
  };
}
